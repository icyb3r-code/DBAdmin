USE [master]

GO

CREATE SERVER ROLE [ServerRole-20120101-174731]

GO

ALTER SERVER ROLE [ServerRole-20120101-174731] ADD MEMBER [SQLCLASS\Administrator]

GO

ALTER SERVER ROLE [securityadmin] ADD MEMBER [ServerRole-20120101-174731]

GO

use [master]

GO

GRANT CREATE ANY DATABASE TO [ServerRole-20120101-174731]

GO

use [master]

GO

GRANT SHUTDOWN TO [ServerRole-20120101-174731]

GO


