USE Test_DB
GO

CREATE SEQUENCE dbo.TestSequence
AS INT

MINVALUE 1
NO MAXVALUE
START WITH 1


use Test_DB

Create Table Test1
(
ID int default (next value for dbo.TestSequence),
RandomText varchar(50)
)

Create Table Test2
(
ID int default (next value for dbo.TestSequence),
RandomText varchar(50)
)

---Table1 then Table2
insert into Test1(RandomText) values ('Insert1')
insert into Test1(RandomText) values ('Insert2')
insert into Test2(RandomText) values ('Insert3')
insert into Test2(RandomText) values ('Insert4')


---Alternating
insert into Test1(RandomText) values ('Insert5')
insert into Test2(RandomText) values ('Insert6')
insert into Test1(RandomText) values ('Insert7')
insert into Test2(RandomText) values ('Insert8')

Select * from Test1
Select * from Test2

----Reset Sequence
ALTER SEQUENCE [dbo].[TestSequence]
 RESTART  WITH 1 

GO


---Table1 then Table2
insert into Test1(RandomText) values ('Insert9')
insert into Test1(RandomText) values ('Insert10')
insert into Test2(RandomText) values ('Insert11')
insert into Test2(RandomText) values ('Insert12')


---Alternating
insert into Test1(RandomText) values ('Insert13')
insert into Test2(RandomText) values ('Insert14')
insert into Test1(RandomText) values ('Insert15')
insert into Test2(RandomText) values ('Insert16')

Select * from Test1
Select * from Test2

--SELECT PREVIOUS Value for TestSequence
---Manually increment sequence
SELECT NEXT VALUE FOR TestSequence

---Using Sequence in insert without the table being bound by the sequence object
Create Table Test3
(
ID int,
RandomText varchar(50)
)

insert into test3 values (Next Value for TestSequence,'Insert1')
insert into test3 values (Next Value for TestSequence,'Insert2')
insert into test3 values (Next Value for TestSequence,'Insert3')
insert into test3 values (Next Value for TestSequence,'Insert4')

select *
from Test3

drop sequence dbo.TestSequence