----Login to contained DB using ContainedUser

create table TestTable
(
column1 int,
column2 varchar(max))

insert into TestTable values (1,'Hello')
insert into TestTable values (2,'Hello')
insert into TestTable values (3,'Hello')
insert into TestTable values (4,'Hello')

delete from TestTable where column1=1

drop table TestTable